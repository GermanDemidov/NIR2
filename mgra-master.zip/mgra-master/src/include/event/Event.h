#ifndef EVENT_H_
#define EVENT_H_

namespace event { 

struct Event {
  Event() {
  } 
};

} 


#endif
